﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Microsoft.Maui.Controls;
using $safeprojectname$.Models;

namespace $safeprojectname$.ViewModels
{
    public class CatStoreViewModel : BindableObject
    {
        private string _searchQuery;
        private ObservableCollection<Product> _products;
        private ObservableCollection<Product> _cart;

        public CatStoreViewModel()
        {
            // Sample data for products
            Products = new ObservableCollection<Product>
            {
                new Product { Name = "Tabby Cat", Price = 50.00m },
                new Product { Name = "Persian Cat", Price = 100.00m },
                new Product { Name = "Siamese Cat", Price = 80.00m },
                new Product { Name = "Maine Coon", Price = 120.00m }
            };

            Cart = new ObservableCollection<Product>();

            // Command to add products to the cart
            AddToCartCommand = new Command<Product>(AddToCart);
        }

        public ObservableCollection<Product> Products
        {
            get => _products;
            set
            {
                _products = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<Product> Cart
        {
            get => _cart;
            set
            {
                _cart = value;
                OnPropertyChanged();
            }
        }

        public ICommand AddToCartCommand { get; }

        // Make sure this method is properly closed
        public void AddToCart(Product product)
        {
            Cart.Add(product);
        }

        // Search functionality
        public string SearchQuery
        {
            get => _searchQuery;
            set
            {
                if (_searchQuery != value)
                {
                    _searchQuery = value;
                    OnPropertyChanged();
                    FilterProducts();
                }
            }
        }

        private void FilterProducts()
        {
            if (string.IsNullOrWhiteSpace(SearchQuery))
            {
                // If search is empty, display all products
                Products = new ObservableCollection<Product>(GetAllProducts());
            }
            else
            {
                // Filter products by name (case insensitive)
                Products = new ObservableCollection<Product>(GetAllProducts().Where(p => p.Name.ToLower().Contains(SearchQuery.ToLower())));
            }
        }

        // Ensure this method is in the correct place and accessible
        private IEnumerable<Product> GetAllProducts()
        {
            return new List<Product>
            {
                new Product { Name = "Tabby Cat", Price = 50.00m },
                new Product { Name = "Persian Cat", Price = 100.00m },
                new Product { Name = "Siamese Cat", Price = 80.00m },
                new Product { Name = "Maine Coon", Price = 120.00m }
            };
        }
    }
}
