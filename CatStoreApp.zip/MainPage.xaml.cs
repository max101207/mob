﻿using $safeprojectname$.Models;
using $safeprojectname$.ViewModels;
using Microsoft.Maui.Controls;

namespace $safeprojectname$
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();

            // Set BindingContext to the instance of CatStoreViewModel
            BindingContext = new CatStoreViewModel();
        }

        // AddToCartCommand to handle adding items to the cart
        public Command AddToCartCommand => new Command<Product>(product =>
        {
            var viewModel = (CatStoreViewModel)BindingContext;
            viewModel.AddToCart(product);
        });
    }
}
